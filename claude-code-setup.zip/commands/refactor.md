# Refactor Command

Refaktoriere Code für bessere Qualität und Wartbarkeit.

## Anweisungen

### 1. Analyse
- Code-Smells identifizieren
- Duplikation finden
- Komplexität messen

### 2. Refactoring-Typen

#### Struktur
- Lange Funktionen aufteilen
- Klassen extrahieren
- Module reorganisieren

#### Typisierung
```python
# Vorher
def process(img, config):
    ...

# Nachher
def process(
    img: np.ndarray,
    config: ProcessingConfig
) -> ProcessedResult:
    ...
```

#### Error Handling
```python
# Vorher
result = model(x)

# Nachher
try:
    result = model(x)
except RuntimeError as e:
    if "out of memory" in str(e):
        logger.error("GPU OOM - reduce batch size")
        raise MemoryError("Insufficient GPU memory") from e
    raise
```

#### PyTorch-spezifisch
```python
# Vorher
features = model(x.cuda())

# Nachher
device = next(model.parameters()).device
features = model(x.to(device))
```

### 3. Prioritäten
1. Korrektheit (Bugs)
2. Klarheit (Lesbarkeit)
3. Performance
4. Erweiterbarkeit

## Eingabe
$ARGUMENTS

## Output
- Refaktorierter Code
- Begründung für Änderungen
- Tests für geänderte Funktionen
