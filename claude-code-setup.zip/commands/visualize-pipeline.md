# Pipeline Visualization Command

Visualisiere und dokumentiere die Anomaly Detection Pipeline.

## Anweisungen

### 1. Pipeline-Diagramm erstellen
```
┌─────────────┐    ┌──────────────┐    ┌─────────────┐
│   Kamera    │───▶│ Preprocessing │───▶│  DINOv3     │
│  (IDS Peak) │    │  (Resize,    │    │  Feature    │
│             │    │   Normalize) │    │  Extractor  │
└─────────────┘    └──────────────┘    └──────┬──────┘
                                              │
                                              ▼
┌─────────────┐    ┌──────────────┐    ┌─────────────┐
│  Heatmap    │◀───│   Scoring    │◀───│   Memory    │
│  Overlay    │    │   (k-NN)     │    │   Bank      │
│             │    │              │    │   (FAISS)   │
└─────────────┘    └──────────────┘    └─────────────┘
```

### 2. Datenfluss dokumentieren
Für jeden Schritt:
- Input Shape/Type
- Transformation
- Output Shape/Type

### 3. Tensor-Shapes durch Pipeline
```python
# Beispiel für 224x224 Input mit ViT-B/16
Step 1: Image (H, W, 3) uint8         # (224, 224, 3)
Step 2: Tensor (1, 3, H, W) float32   # (1, 3, 224, 224)
Step 3: Normalized (1, 3, H, W)       # ImageNet mean/std
Step 4: Features (1, N, D)            # (1, 196, 768) für ViT-B
Step 5: Anomaly Map (H', W')          # (14, 14) patch-level
Step 6: Upsampled (H, W)              # (224, 224) pixel-level
```

### 4. Konfigurationen
- Welche Parameter sind einstellbar?
- Defaults vs. optimale Werte
- Trade-offs (Speed vs. Accuracy)

## Eingabe
$ARGUMENTS

## Output
- ASCII/Mermaid Diagramm
- Shape-Tabelle
- Konfigurations-Dokumentation
