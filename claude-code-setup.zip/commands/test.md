# Test Generation Command

Generiere pytest-Tests für das angegebene Modul.

## Anweisungen

Erstelle umfassende Tests mit Fokus auf Computer Vision:

### 1. Unit Tests
- Alle öffentlichen Funktionen/Methoden
- Edge Cases (leere Bilder, falsche Shapes)
- Type Validation

### 2. CV-spezifische Tests
- Tensor Shape Tests (Input/Output)
- Farbformat-Tests (BGR/RGB Konsistenz)
- Normalisierung-Tests
- Device-Tests (CPU/GPU)

### 3. Integration Tests
- Pipeline End-to-End
- Model Loading
- Feature Extraction

### 4. Performance Tests (optional)
- Inferenz-Zeit Benchmarks
- Memory Usage

## Test-Struktur
```python
import pytest
import torch
import numpy as np
from pathlib import Path

# Fixtures
@pytest.fixture
def sample_image():
    """RGB Testbild (224x224x3)."""
    return np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8)

@pytest.fixture
def sample_tensor():
    """Normalisierter Tensor (1, 3, 224, 224)."""
    return torch.randn(1, 3, 224, 224)

# Shape Tests
def test_output_shape(model, sample_tensor):
    output = model(sample_tensor)
    assert output.shape == expected_shape

# Device Tests
@pytest.mark.parametrize("device", ["cpu", "cuda"])
def test_device_handling(model, sample_tensor, device):
    if device == "cuda" and not torch.cuda.is_available():
        pytest.skip("CUDA not available")
    ...
```

## Eingabe
$ARGUMENTS

## Output
- Vollständige pytest-Datei
- Fixtures für wiederverwendbare Test-Daten
- Parametrisierte Tests wo sinnvoll
- Marker für langsame/GPU-Tests
