# Documentation Command

Erstelle oder aktualisiere Dokumentation für das Projekt oder Modul.

## Anweisungen

### 1. Modul-Dokumentation
Falls ein spezifisches Modul angegeben:
- API-Referenz mit allen öffentlichen Klassen/Funktionen
- Beispiel-Code für typische Verwendung
- Parameter-Beschreibungen mit Typen

### 2. Projekt-Dokumentation
Falls kein Modul angegeben:
- README.md aktualisieren
- Installation & Setup
- Quick Start Guide
- Architektur-Übersicht

### 3. CV-spezifische Dokumentation
- Tensor-Shapes und erwartete Formate
- Preprocessing-Pipeline
- Model-Konfiguration
- Performance-Charakteristiken

## Docstring-Format (Google Style)
```python
def extract_features(
    image: np.ndarray,
    model: nn.Module,
    device: str = "cuda"
) -> torch.Tensor:
    """Extrahiert DINOv3 Features aus einem Bild.

    Args:
        image: Input-Bild als numpy array (H, W, 3), RGB, uint8.
        model: Vortrainiertes DINOv3-Modell.
        device: Ziel-Device ("cuda" oder "cpu").

    Returns:
        Feature-Tensor der Shape (1, num_patches, embed_dim).

    Raises:
        ValueError: Falls Bild nicht 3 Kanäle hat.

    Example:
        >>> model = load_dinov3("vitb16")
        >>> img = cv2.imread("test.jpg")
        >>> img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        >>> features = extract_features(img_rgb, model)
        >>> print(features.shape)  # (1, 196, 768)
    """
```

## Eingabe
$ARGUMENTS

## Output
- Markdown-Dokumentation oder
- Aktualisierte Docstrings im Code
