# Benchmark Command

Führe Benchmarks für Anomaly Detection Methoden durch.

## Anweisungen

Vergleiche Methoden systematisch für die MAS-Thesis:

### 1. Methoden
- **PatchCore**: Memory Bank mit k-NN
- **AD-DINOv3**: Zero-Shot mit Foundation Model Features

### 2. Metriken
```python
# Standard AD Metriken
- AUROC (Image-Level)
- AUROC (Pixel-Level)
- F1-Score @ optimal threshold
- Average Precision (AP)
- Pro-Score (für Segmentierung)
```

### 3. Performance Metriken
```python
- Inferenz-Zeit (ms/image)
- Memory Usage (MB)
- Throughput (images/sec)
```

### 4. Benchmark-Protokoll
```python
# Für jeden Datensatz:
1. Training/Reference Set laden
2. Memory Bank aufbauen (falls nötig)
3. Test Set evaluieren
4. Metriken berechnen
5. Ergebnisse loggen
```

## Eingabe
$ARGUMENTS

Optionen:
- `--dataset [path]`: Datensatz-Pfad
- `--method [patchcore|dinov3|all]`: Methode
- `--backbone [vits|vitb|vitl]`: Backbone-Größe

## Output Format
```
## Benchmark Results

### Dataset: [Name]
| Methode | AUROC (Img) | AUROC (Pix) | F1 | Zeit (ms) |
|---------|-------------|-------------|-----|-----------|
| PatchCore | X.XX | X.XX | X.XX | XX |
| AD-DINOv3 | X.XX | X.XX | X.XX | XX |

### Analyse
[Stärken/Schwächen jeder Methode]

### Empfehlung
[Welche Methode für welchen Use Case]
```
