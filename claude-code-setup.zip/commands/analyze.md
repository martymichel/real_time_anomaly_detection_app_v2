# Code Analysis Command

Analysiere den angegebenen Code oder das Modul systematisch.

## Anweisungen

Führe eine umfassende Code-Analyse durch:

### 1. Struktur-Analyse
- Klassen und deren Verantwortlichkeiten
- Funktionen und deren Signaturen
- Imports und Dependencies

### 2. Qualitäts-Check
- Type Hints vorhanden?
- Docstrings vollständig?
- Error Handling implementiert?
- Logging statt print()?

### 3. Computer Vision spezifisch
- Tensor-Shapes dokumentiert?
- Farbformat-Konvertierungen korrekt (BGR/RGB)?
- Memory-Management bei großen Bildern?
- GPU/CPU Device-Handling?

### 4. PyTorch Best Practices
- `torch.no_grad()` bei Inferenz?
- Batch-Processing wo möglich?
- Model im eval() Modus?

### 5. Verbesserungsvorschläge
- Performance-Optimierungen
- Code-Duplikation
- Bessere Abstraktionen

## Eingabe
$ARGUMENTS

## Output Format
```
## Analyse: [Datei/Modul]

### Zusammenfassung
[Kurzbeschreibung]

### Struktur
[Klassen, Funktionen]

### Qualität
✅ [Was gut ist]
⚠️ [Was verbessert werden sollte]

### CV-spezifisch
[Tensor-Handling, Shapes, etc.]

### Empfehlungen
1. [Priorität 1]
2. [Priorität 2]
...
```
