# Model Analysis Command

Analysiere ein PyTorch/Transformers Modell für Anomaly Detection.

## Anweisungen

### 1. Architektur-Analyse
- Backbone-Typ (ViT, ResNet, etc.)
- Anzahl Parameter (trainierbar vs. frozen)
- Input/Output Shapes
- Intermediate Feature Shapes

### 2. Memory & Performance
```python
# Automatische Analyse
from torchinfo import summary
summary(model, input_size=(1, 3, 224, 224), device="cuda")
```
- GPU Memory Footprint
- Geschätzte Inferenz-Zeit
- Batch-Size Empfehlungen

### 3. Feature Extraction Points
Für Anomaly Detection relevant:
- Welche Layer-Outputs sind nutzbar?
- Patch-Token vs. CLS-Token
- Multi-Scale Features?

### 4. Kompatibilität
- ONNX-Export möglich?
- TensorRT-Kompatibilität?
- Quantisierung möglich?

## Eingabe
$ARGUMENTS

Falls kein Modell angegeben, analysiere die Modelle in `models/`:
- facebook_dinov3-vitb16
- facebook_dinov3-vitl16
- facebook_dinov3-vits16

## Output Format
```
## Model: [Name]

### Architektur
- Typ: [ViT-B/16, etc.]
- Parameter: [X.X M]
- Input: [Shape]
- Output: [Shape]

### Feature Maps
| Layer | Shape | Verwendung |
|-------|-------|------------|
| ... | ... | ... |

### Performance (geschätzt)
- Memory: ~X GB
- Inferenz: ~X ms/image
- Max Batch Size: X (bei 8GB VRAM)

### Empfehlungen für Anomaly Detection
[Welche Features nutzen, etc.]
```
